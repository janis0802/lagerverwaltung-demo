# Lagerverwaltung Demo
Dies ist ein Beispielprojekt für ein Rettungsdienst-Lagersystem.